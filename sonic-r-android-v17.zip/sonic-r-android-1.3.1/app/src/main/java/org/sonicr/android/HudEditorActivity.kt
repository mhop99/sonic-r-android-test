package org.sonicr.android

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.min

/**
 * Visual editor for the race HUD layout.
 *
 * It shows an approximate 4:3 preview of the race screen with one box per HUD group.
 * Boxes can be dragged with a finger or moved with a gamepad. It only writes the same
 * "hud_<group>_x / _y / _scale / _opacity" preferences that the manual sliders in the
 * settings screen use, so the game side needs no changes.
 */
class HudEditorActivity : Activity() {

    private class HudItem(
        val key: String,
        val labelRes: Int,
        val shortRes: Int,
        val color: Int,
        val baseX: Float,
        val baseY: Float,
        val baseW: Float,
        val baseH: Float
    ) {
        var offX = 0
        var offY = 0
        var scale = 100
        var opacity = 100

        // Same math as the game: scale around the 640x480 center, then add the offset.
        fun left(): Float = 320f + offX + (baseX - 320f) * scale / 100f
        fun top(): Float = 240f + offY + (baseY - 240f) * scale / 100f
        fun width(): Float = baseW * scale / 100f
        fun height(): Float = baseH * scale / 100f
    }

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var items: List<HudItem>
    private lateinit var preview: PreviewView
    private lateinit var selNameText: TextView
    private lateinit var selValuesText: TextView
    private var selected = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(SettingsActivity.PREFS_NAME, Context.MODE_PRIVATE)

        // Default boxes for the Grand Prix race screen in the 640x480 logical space.
        items = listOf(
            HudItem("minimap", R.string.settings_hud_minimap, R.string.hud_short_minimap,
                Color.parseColor("#4FC3F7"), 432f, 304f, 192f, 160f),
            HudItem("timers", R.string.settings_hud_timers, R.string.hud_short_timers,
                Color.parseColor("#FFB74D"), 512f, 16f, 112f, 90f),
            HudItem("rings", R.string.settings_hud_rings, R.string.hud_short_rings,
                Color.parseColor("#FFEE58"), 16f, 16f, 88f, 32f),
            HudItem("collect", R.string.settings_hud_collect, R.string.hud_short_collect,
                Color.parseColor("#81C784"), 16f, 432f, 88f, 32f),
            HudItem("ranking", R.string.settings_hud_ranking, R.string.hud_short_ranking,
                Color.parseColor("#BA68C8"), 24f, 128f, 76f, 222f),
            HudItem("indicators", R.string.settings_hud_indicators, R.string.hud_short_indicators,
                Color.parseColor("#F06292"), 224f, 82f, 192f, 74f)
        )
        for (item in items) {
            loadItem(item)
        }

        buildUi()
        hideSystemUI()
        refreshInfo()
    }

    private fun loadItem(item: HudItem) {
        item.offX = prefs.getInt("hud_${item.key}_x", 0).coerceIn(-160, 160)
        item.offY = prefs.getInt("hud_${item.key}_y", 0).coerceIn(-120, 120)
        item.scale = prefs.getInt("hud_${item.key}_scale", 100).coerceIn(50, 150)
        item.opacity = prefs.getInt("hud_${item.key}_opacity", 100).coerceIn(0, 100)
    }

    private fun saveItem(item: HudItem) {
        prefs.edit()
            .putInt("hud_${item.key}_x", item.offX)
            .putInt("hud_${item.key}_y", item.offY)
            .putInt("hud_${item.key}_scale", item.scale)
            .putInt("hud_${item.key}_opacity", item.opacity)
            .apply()
    }

    private fun moveBy(dx: Int, dy: Int, save: Boolean) {
        val item = items[selected]
        item.offX = (item.offX + dx).coerceIn(-160, 160)
        item.offY = (item.offY + dy).coerceIn(-120, 120)
        if (save) {
            saveItem(item)
        }
        refreshInfo()
        preview.invalidate()
    }

    private fun changeScale(delta: Int) {
        val item = items[selected]
        item.scale = (item.scale + delta).coerceIn(50, 150)
        saveItem(item)
        refreshInfo()
        preview.invalidate()
    }

    private fun changeOpacity(delta: Int) {
        val item = items[selected]
        item.opacity = (item.opacity + delta).coerceIn(0, 100)
        saveItem(item)
        refreshInfo()
        preview.invalidate()
    }

    private fun resetItem(item: HudItem) {
        item.offX = 0
        item.offY = 0
        item.scale = 100
        item.opacity = 100
        saveItem(item)
    }

    private fun selectNext() {
        selected = (selected + 1) % items.size
        refreshInfo()
        preview.invalidate()
    }

    private fun refreshInfo() {
        val item = items[selected]
        selNameText.text = getString(item.labelRes)
        selValuesText.text = getString(R.string.settings_hud_size) + " " + item.scale + "%   " +
            getString(R.string.settings_hud_opacity) + " " + item.opacity + "%\nX " + item.offX +
            "   Y " + item.offY
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun styledButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            setBackgroundResource(R.drawable.btn_retro_silver)
            setTextColor(Color.parseColor("#263238"))
            textSize = 12f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            isFocusable = false
            minWidth = 0
            minimumWidth = 0
            stateListAnimator = null
            setOnClickListener { onClick() }
        }
    }

    private fun adjustRow(labelRes: Int, onMinus: () -> Unit, onPlus: () -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(
            TextView(this).apply {
                setText(labelRes)
                setTextColor(Color.parseColor("#B8C8D8"))
                textSize = 12f
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        row.addView(styledButton("\u2212", onMinus), LinearLayout.LayoutParams(dp(52), dp(36)))
        val plusParams = LinearLayout.LayoutParams(dp(52), dp(36))
        plusParams.leftMargin = dp(6)
        row.addView(styledButton("+", onPlus), plusParams)
        return row
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#05102A"))
        }

        preview = PreviewView(this)
        val previewParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        previewParams.setMargins(dp(8), dp(8), dp(8), dp(8))
        root.addView(preview, previewParams)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }

        panel.addView(TextView(this).apply {
            setText(R.string.hud_editor_title)
            setTextColor(Color.parseColor("#82B1FF"))
            textSize = 15f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        })
        panel.addView(TextView(this).apply {
            setText(R.string.hud_editor_hint)
            setTextColor(Color.parseColor("#9CA3AF"))
            textSize = 10f
        })

        selNameText = TextView(this).apply {
            setTextColor(Color.parseColor("#FFE600"))
            textSize = 14f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        }
        val nameParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        nameParams.topMargin = dp(10)
        panel.addView(selNameText, nameParams)

        selValuesText = TextView(this).apply {
            setTextColor(Color.parseColor("#E0F2FE"))
            textSize = 11f
        }
        val valuesParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        valuesParams.bottomMargin = dp(8)
        panel.addView(selValuesText, valuesParams)

        panel.addView(adjustRow(R.string.settings_hud_size, { changeScale(-5) }, { changeScale(5) }))
        val opacityRow = adjustRow(R.string.settings_hud_opacity, { changeOpacity(-5) }, { changeOpacity(5) })
        val opacityParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        opacityParams.topMargin = dp(6)
        panel.addView(opacityRow, opacityParams)

        val resetItemParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(38)
        )
        resetItemParams.topMargin = dp(12)
        panel.addView(styledButton(getString(R.string.hud_editor_reset_item)) {
            resetItem(items[selected])
            refreshInfo()
            preview.invalidate()
        }, resetItemParams)

        val resetAllParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(38)
        )
        resetAllParams.topMargin = dp(6)
        panel.addView(styledButton(getString(R.string.hud_editor_reset_all)) {
            for (item in items) {
                resetItem(item)
            }
            refreshInfo()
            preview.invalidate()
        }, resetAllParams)

        val doneParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(38)
        )
        doneParams.topMargin = dp(6)
        panel.addView(styledButton(getString(R.string.hud_editor_done)) { finish() }, doneParams)

        val helpParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        helpParams.topMargin = dp(10)
        panel.addView(TextView(this).apply {
            setText(R.string.hud_editor_controller_help)
            setTextColor(Color.parseColor("#9CA3AF"))
            textSize = 9f
        }, helpParams)

        val scroll = ScrollView(this)
        scroll.addView(panel)
        root.addView(scroll, LinearLayout.LayoutParams(dp(250), LinearLayout.LayoutParams.MATCH_PARENT))

        setContentView(root)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val step = if (event.repeatCount > 8) 8 else 3
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    moveBy(-step, 0, true)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    moveBy(step, 0, true)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP -> {
                    moveBy(0, -step, true)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    moveBy(0, step, true)
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_A,
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {
                    if (event.repeatCount == 0) {
                        selectNext()
                    }
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_L1 -> {
                    changeScale(-5)
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_R1 -> {
                    changeScale(5)
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_X -> {
                    changeOpacity(-5)
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_Y -> {
                    changeOpacity(5)
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_START -> {
                    resetItem(items[selected])
                    refreshInfo()
                    preview.invalidate()
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_B -> {
                    finish()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun hideSystemUI() {
        window.decorView.post {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        }
    }

    /** Draws the approximate race screen and handles dragging of the HUD boxes. */
    private inner class PreviewView(context: Context) : View(context) {

        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        }
        private val dash = DashPathEffect(floatArrayOf(10f, 8f), 0f)

        private var unit = 1f
        private var originX = 0f
        private var originY = 0f
        private var dragging = false
        private var lastX = 0f
        private var lastY = 0f
        private var accX = 0f
        private var accY = 0f

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            unit = min(w / 640f, h / 480f)
            originX = (w - 640f * unit) / 2f
            originY = (h - 480f * unit) / 2f

            bgPaint.color = Color.parseColor("#14305C")
            canvas.drawRect(originX, originY, originX + 640f * unit, originY + 480f * unit, bgPaint)

            // Center guides
            strokePaint.pathEffect = dash
            strokePaint.color = Color.parseColor("#33FFFFFF")
            strokePaint.strokeWidth = 1f
            canvas.drawLine(originX + 320f * unit, originY, originX + 320f * unit, originY + 480f * unit, strokePaint)
            canvas.drawLine(originX, originY + 240f * unit, originX + 640f * unit, originY + 240f * unit, strokePaint)

            // Screen frame
            strokePaint.pathEffect = null
            strokePaint.color = Color.parseColor("#82B1FF")
            strokePaint.strokeWidth = 3f
            canvas.drawRect(originX, originY, originX + 640f * unit, originY + 480f * unit, strokePaint)

            for ((index, item) in items.withIndex()) {
                val rect = RectF(
                    originX + item.left() * unit,
                    originY + item.top() * unit,
                    originX + (item.left() + item.width()) * unit,
                    originY + (item.top() + item.height()) * unit
                )
                val hidden = item.opacity == 0
                val alpha = if (hidden) 40 else 60 + item.opacity * 160 / 100
                fillPaint.color = (item.color and 0x00FFFFFF) or (alpha shl 24)
                canvas.drawRoundRect(rect, 8f, 8f, fillPaint)

                val isSelected = index == selected
                strokePaint.strokeWidth = if (isSelected) 5f else 2f
                strokePaint.color = if (isSelected) Color.WHITE else item.color
                strokePaint.pathEffect = if (hidden) dash else null
                canvas.drawRoundRect(rect, 8f, 8f, strokePaint)

                canvas.save()
                canvas.clipRect(rect)
                textPaint.textSize = dp(10).toFloat()
                var label = getString(item.shortRes)
                if (hidden) {
                    label = label + " (" + getString(R.string.hud_editor_hidden) + ")"
                }
                canvas.drawText(label, rect.centerX(), rect.centerY() + textPaint.textSize / 3f, textPaint)
                canvas.restore()
            }
            strokePaint.pathEffect = null
        }

        private fun hit(item: HudItem, lx: Float, ly: Float, slop: Float): Boolean {
            return lx >= item.left() - slop && lx <= item.left() + item.width() + slop &&
                ly >= item.top() - slop && ly <= item.top() + item.height() + slop
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val lx = (event.x - originX) / unit
                    val ly = (event.y - originY) / unit
                    val slop = dp(10) / unit
                    var picked = -1
                    if (hit(items[selected], lx, ly, slop)) {
                        picked = selected
                    } else {
                        for (i in items.indices.reversed()) {
                            if (hit(items[i], lx, ly, slop)) {
                                picked = i
                                break
                            }
                        }
                    }
                    if (picked >= 0) {
                        selected = picked
                        dragging = true
                        lastX = event.x
                        lastY = event.y
                        accX = 0f
                        accY = 0f
                        refreshInfo()
                        invalidate()
                        parent?.requestDisallowInterceptTouchEvent(true)
                    }
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (dragging) {
                        accX += (event.x - lastX) / unit
                        accY += (event.y - lastY) / unit
                        lastX = event.x
                        lastY = event.y
                        val dx = accX.toInt()
                        val dy = accY.toInt()
                        if (dx != 0 || dy != 0) {
                            accX -= dx
                            accY -= dy
                            moveBy(dx, dy, false)
                        }
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        saveItem(items[selected])
                    }
                    return true
                }
            }
            return true
        }
    }
}
