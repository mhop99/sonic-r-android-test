package org.sonicr.android

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.sonicr.android.databinding.ActivitySettingsBinding

class SettingsActivity : Activity() {

    companion object {
        const val PREFS_NAME = "sonicr_settings"
        const val KEY_MUSIC_VOLUME = "music_volume"
        const val KEY_SFX_VOLUME = "sfx_volume"
        const val DEFAULT_MUSIC_VOLUME = 0.8f
        const val DEFAULT_SFX_VOLUME = 1.0f
        const val KEY_GAMEPAD_STICK_DEADZONE = "gamepad_stick_deadzone"
        const val DEFAULT_GAMEPAD_STICK_DEADZONE = 25
        const val KEY_GRIP_PERCENT = "grip_percent"
        const val DEFAULT_GRIP_PERCENT = 100
        const val KEY_CAM_DISTANCE_PERCENT = "cam_distance_percent"
        const val DEFAULT_CAM_DISTANCE_PERCENT = 100
        const val KEY_CAM_HEIGHT_OFFSET = "cam_height_offset"
        const val DEFAULT_CAM_HEIGHT_OFFSET = 0
        const val KEY_SHOW_FPS = "show_fps"
        const val DEFAULT_SHOW_FPS = false
        const val KEY_PLAYER_EFFECT = "player_effect_level"
        const val DEFAULT_PLAYER_EFFECT = 0

        const val KEY_CONTROLS_CUSTOM = "controls_custom"
        const val KEY_TOUCH_CONTROLS_ENABLED = "touch_controls_enabled"
        const val DEFAULT_TOUCH_CONTROLS_ENABLED = true
        // 7 independent control keys
        const val KEY_CTRL_DPAD_X = "ctrl_dpad_x"
        const val KEY_CTRL_DPAD_Y = "ctrl_dpad_y"
        const val KEY_CTRL_DPAD_SCALE = "ctrl_dpad_scale"

        const val KEY_CTRL_DRIFT_L_X = "ctrl_driftL_x"
        const val KEY_CTRL_DRIFT_L_Y = "ctrl_driftL_y"
        const val KEY_CTRL_DRIFT_L_SCALE = "ctrl_driftL_scale"

        const val KEY_CTRL_ACCEL_X = "ctrl_accel_x"
        const val KEY_CTRL_ACCEL_Y = "ctrl_accel_y"
        const val KEY_CTRL_ACCEL_SCALE = "ctrl_accel_scale"

        const val KEY_CTRL_JUMP_X = "ctrl_jump_x"
        const val KEY_CTRL_JUMP_Y = "ctrl_jump_y"
        const val KEY_CTRL_JUMP_SCALE = "ctrl_jump_scale"

        const val KEY_CTRL_DRIFT_R_X = "ctrl_driftR_x"
        const val KEY_CTRL_DRIFT_R_Y = "ctrl_driftR_y"
        const val KEY_CTRL_DRIFT_R_SCALE = "ctrl_driftR_scale"

        const val KEY_CTRL_LOOK_X = "ctrl_look_x"
        const val KEY_CTRL_LOOK_Y = "ctrl_look_y"
        const val KEY_CTRL_LOOK_SCALE = "ctrl_look_scale"

        const val KEY_CTRL_START_X = "ctrl_start_x"
        const val KEY_CTRL_START_Y = "ctrl_start_y"
        const val KEY_CTRL_START_SCALE = "ctrl_start_scale"

        // Legacy cluster keys (cleaned up on reset)
        private const val LEGACY_KEY_DPAD_X = "controls_dpad_x"
        private const val LEGACY_KEY_DPAD_Y = "controls_dpad_y"
        private const val LEGACY_KEY_DPAD_SCALE = "controls_dpad_scale"
        private const val LEGACY_KEY_ACTIONS_X = "controls_actions_x"
        private const val LEGACY_KEY_ACTIONS_Y = "controls_actions_y"
        private const val LEGACY_KEY_ACTIONS_SCALE = "controls_actions_scale"
        private const val LEGACY_KEY_START_X = "controls_start_x"
        private const val LEGACY_KEY_START_Y = "controls_start_y"
        private const val LEGACY_KEY_START_SCALE = "controls_start_scale"
    }

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        val musicVolume = prefs.getFloat(KEY_MUSIC_VOLUME, DEFAULT_MUSIC_VOLUME)
        val sfxVolume = prefs.getFloat(KEY_SFX_VOLUME, DEFAULT_SFX_VOLUME)

        if (!prefs.contains(KEY_MUSIC_VOLUME) || !prefs.contains(KEY_SFX_VOLUME)) {
            prefs.edit()
                .putFloat(KEY_MUSIC_VOLUME, musicVolume)
                .putFloat(KEY_SFX_VOLUME, sfxVolume)
                .apply()
        }

        val musicProgress = (musicVolume * 100).toInt().coerceIn(0, 100)
        val sfxProgress = (sfxVolume * 100).toInt().coerceIn(0, 100)

        binding.seekMusicVolume.progress = musicProgress
        binding.musicVolumeText.text = "$musicProgress%"

        binding.seekSfxVolume.progress = sfxProgress
        binding.sfxVolumeText.text = "$sfxProgress%"

        binding.seekMusicVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.musicVolumeText.text = "$progress%"
                prefs.edit().putFloat(KEY_MUSIC_VOLUME, progress / 100f).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.seekSfxVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                binding.sfxVolumeText.text = "$progress%"
                prefs.edit().putFloat(KEY_SFX_VOLUME, progress / 100f).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        var touchControlsOn = prefs.getBoolean(
            KEY_TOUCH_CONTROLS_ENABLED,
            DEFAULT_TOUCH_CONTROLS_ENABLED
        )
        fun renderTouchControlsToggle() {
            val btn = binding.btnToggleTouchControls
            if (touchControlsOn) {
                btn.setText(R.string.settings_touch_controls_on)
                btn.setBackgroundResource(R.drawable.btn_retro_sega)
                btn.setTextColor(android.graphics.Color.WHITE)
            } else {
                btn.setText(R.string.settings_touch_controls_off)
                btn.setBackgroundResource(R.drawable.btn_retro_silver)
                btn.setTextColor(android.graphics.Color.parseColor("#263238"))
            }
        }
        renderTouchControlsToggle()
        binding.btnToggleTouchControls.setOnClickListener {
            touchControlsOn = !touchControlsOn
            prefs.edit().putBoolean(KEY_TOUCH_CONTROLS_ENABLED, touchControlsOn).apply()
            renderTouchControlsToggle()
        }

        // Discrete left-stick steering threshold options for gamepads.
        val gamepadDeadzoneOptions = intArrayOf(15, 20, 25, 30, 35, 40, 45, 50, 55, 60)
        val savedDeadzone = prefs.getInt(
            KEY_GAMEPAD_STICK_DEADZONE,
            DEFAULT_GAMEPAD_STICK_DEADZONE
        )
        val deadzoneIndex = gamepadDeadzoneOptions.indexOf(savedDeadzone)
            .takeIf { it >= 0 }
            ?: gamepadDeadzoneOptions.indexOf(DEFAULT_GAMEPAD_STICK_DEADZONE)

        binding.seekGamepadDeadzone.max = gamepadDeadzoneOptions.lastIndex
        binding.seekGamepadDeadzone.progress = deadzoneIndex
        binding.gamepadDeadzoneText.text = "${gamepadDeadzoneOptions[deadzoneIndex]}%"
        binding.seekGamepadDeadzone.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val percent = gamepadDeadzoneOptions[progress.coerceIn(0, gamepadDeadzoneOptions.lastIndex)]
                binding.gamepadDeadzoneText.text = "$percent%"
                if (fromUser) {
                    prefs.edit().putInt(KEY_GAMEPAD_STICK_DEADZONE, percent).apply()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Grip assist: 100 = original physics, higher = less sliding on turns.
        val gripOptions = intArrayOf(100, 125, 150, 175, 200)
        fun gripLabel(percent: Int): String =
            if (percent == 100) getString(R.string.settings_grip_original) else "$percent%"
        val savedGrip = prefs.getInt(KEY_GRIP_PERCENT, DEFAULT_GRIP_PERCENT)
        val gripIndex = gripOptions.indexOf(savedGrip)
            .takeIf { it >= 0 }
            ?: gripOptions.indexOf(DEFAULT_GRIP_PERCENT)

        binding.seekGrip.max = gripOptions.lastIndex
        binding.seekGrip.progress = gripIndex
        binding.gripText.text = gripLabel(gripOptions[gripIndex])
        binding.seekGrip.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val percent = gripOptions[progress.coerceIn(0, gripOptions.lastIndex)]
                binding.gripText.text = gripLabel(percent)
                if (fromUser) {
                    prefs.edit().putInt(KEY_GRIP_PERCENT, percent).apply()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Camera distance: 100 = original, lower = closer, higher = farther (visual only).
        val camDistanceOptions = intArrayOf(70, 85, 100, 125, 150)
        fun camDistanceLabel(percent: Int): String =
            if (percent == 100) getString(R.string.settings_camera_original) else "$percent%"
        val savedCamDistance = prefs.getInt(KEY_CAM_DISTANCE_PERCENT, DEFAULT_CAM_DISTANCE_PERCENT)
        val camDistanceIndex = camDistanceOptions.indexOf(savedCamDistance)
            .takeIf { it >= 0 }
            ?: camDistanceOptions.indexOf(DEFAULT_CAM_DISTANCE_PERCENT)

        binding.seekCamDistance.max = camDistanceOptions.lastIndex
        binding.seekCamDistance.progress = camDistanceIndex
        binding.camDistanceText.text = camDistanceLabel(camDistanceOptions[camDistanceIndex])
        binding.seekCamDistance.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val percent = camDistanceOptions[progress.coerceIn(0, camDistanceOptions.lastIndex)]
                binding.camDistanceText.text = camDistanceLabel(percent)
                if (fromUser) {
                    prefs.edit().putInt(KEY_CAM_DISTANCE_PERCENT, percent).apply()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Camera height offset: 0 = original, negative = lower, positive = higher (visual only).
        val camHeightOptions = intArrayOf(-32, 0, 32, 64, 96)
        fun camHeightLabel(offset: Int): String = when {
            offset == 0 -> getString(R.string.settings_camera_original)
            offset > 0 -> "+$offset"
            else -> "$offset"
        }
        val savedCamHeight = prefs.getInt(KEY_CAM_HEIGHT_OFFSET, DEFAULT_CAM_HEIGHT_OFFSET)
        val camHeightIndex = camHeightOptions.indexOf(savedCamHeight)
            .takeIf { it >= 0 }
            ?: camHeightOptions.indexOf(DEFAULT_CAM_HEIGHT_OFFSET)

        binding.seekCamHeight.max = camHeightOptions.lastIndex
        binding.seekCamHeight.progress = camHeightIndex
        binding.camHeightText.text = camHeightLabel(camHeightOptions[camHeightIndex])
        binding.seekCamHeight.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val offset = camHeightOptions[progress.coerceIn(0, camHeightOptions.lastIndex)]
                binding.camHeightText.text = camHeightLabel(offset)
                if (fromUser) {
                    prefs.edit().putInt(KEY_CAM_HEIGHT_OFFSET, offset).apply()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Player effect: 0 = off, 1..3 = drift-fire trail strength (visual only).
        val effectLabels = intArrayOf(
            R.string.settings_effect_off,
            R.string.settings_effect_subtle,
            R.string.settings_effect_normal,
            R.string.settings_effect_lots
        )
        val savedEffect = prefs.getInt(KEY_PLAYER_EFFECT, DEFAULT_PLAYER_EFFECT)
            .coerceIn(0, effectLabels.lastIndex)
        binding.seekPlayerEffect.max = effectLabels.lastIndex
        binding.seekPlayerEffect.progress = savedEffect
        binding.playerEffectText.setText(effectLabels[savedEffect])
        binding.seekPlayerEffect.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val level = progress.coerceIn(0, effectLabels.lastIndex)
                binding.playerEffectText.setText(effectLabels[level])
                if (fromUser) {
                    prefs.edit().putInt(KEY_PLAYER_EFFECT, level).apply()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // FPS counter toggle.
        var showFps = prefs.getBoolean(KEY_SHOW_FPS, DEFAULT_SHOW_FPS)
        fun renderFpsToggle() {
            val btn = binding.btnToggleFps
            if (showFps) {
                btn.setText(R.string.settings_touch_controls_on)
                btn.setBackgroundResource(R.drawable.btn_retro_sega)
                btn.setTextColor(android.graphics.Color.WHITE)
            } else {
                btn.setText(R.string.settings_touch_controls_off)
                btn.setBackgroundResource(R.drawable.btn_retro_silver)
                btn.setTextColor(android.graphics.Color.parseColor("#263238"))
            }
        }
        renderFpsToggle()
        binding.btnToggleFps.setOnClickListener {
            showFps = !showFps
            prefs.edit().putBoolean(KEY_SHOW_FPS, showFps).apply()
            renderFpsToggle()
        }

        buildHudCustomization(prefs)

        // Manual sliders stay hidden by default; the visual editor is the main way to customize the HUD.
        binding.hudCustomizationContainer.visibility = View.GONE
        binding.btnToggleHudSliders.setOnClickListener {
            val show = binding.hudCustomizationContainer.visibility != View.VISIBLE
            binding.hudCustomizationContainer.visibility = if (show) View.VISIBLE else View.GONE
            binding.btnToggleHudSliders.setText(
                if (show) R.string.hud_editor_hide_sliders else R.string.hud_editor_show_sliders
            )
        }
        binding.btnOpenHudEditor.setOnClickListener {
            startActivity(Intent(this, HudEditorActivity::class.java))
        }

        binding.btnCustomizeControls.setOnClickListener {
            startActivity(Intent(this, CustomizeControlsActivity::class.java))
        }

        binding.btnResetControls.setOnClickListener {
            prefs.edit()
                .putBoolean(KEY_CONTROLS_CUSTOM, false)
                // Remove 7 per-control keys
                .remove(KEY_CTRL_DPAD_X)
                .remove(KEY_CTRL_DPAD_Y)
                .remove(KEY_CTRL_DPAD_SCALE)
                .remove(KEY_CTRL_DRIFT_L_X)
                .remove(KEY_CTRL_DRIFT_L_Y)
                .remove(KEY_CTRL_DRIFT_L_SCALE)
                .remove(KEY_CTRL_ACCEL_X)
                .remove(KEY_CTRL_ACCEL_Y)
                .remove(KEY_CTRL_ACCEL_SCALE)
                .remove(KEY_CTRL_JUMP_X)
                .remove(KEY_CTRL_JUMP_Y)
                .remove(KEY_CTRL_JUMP_SCALE)
                .remove(KEY_CTRL_DRIFT_R_X)
                .remove(KEY_CTRL_DRIFT_R_Y)
                .remove(KEY_CTRL_DRIFT_R_SCALE)
                .remove(KEY_CTRL_LOOK_X)
                .remove(KEY_CTRL_LOOK_Y)
                .remove(KEY_CTRL_LOOK_SCALE)
                .remove(KEY_CTRL_START_X)
                .remove(KEY_CTRL_START_Y)
                .remove(KEY_CTRL_START_SCALE)
                // Clean up legacy cluster keys
                .remove(LEGACY_KEY_DPAD_X)
                .remove(LEGACY_KEY_DPAD_Y)
                .remove(LEGACY_KEY_DPAD_SCALE)
                .remove(LEGACY_KEY_ACTIONS_X)
                .remove(LEGACY_KEY_ACTIONS_Y)
                .remove(LEGACY_KEY_ACTIONS_SCALE)
                .remove(LEGACY_KEY_START_X)
                .remove(LEGACY_KEY_START_Y)
                .remove(LEGACY_KEY_START_SCALE)
                .apply()
            Toast.makeText(this, R.string.toast_controls_reset, Toast.LENGTH_SHORT).show()
        }

        binding.btnDisplaySettings.setOnClickListener {
            startActivity(Intent(this, ModsActivity::class.java))
        }

        binding.btnAbout.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        binding.btnBack.setOnClickListener {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        // The visual HUD editor may have changed the saved values; rebuild the manual sliders.
        if (::binding.isInitialized) {
            buildHudCustomization(getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE))
        }
    }

    private data class HudGroupSpec(val key: String, val titleRes: Int)

    private fun buildHudCustomization(prefs: android.content.SharedPreferences) {
        val container = binding.hudCustomizationContainer
        container.removeAllViews()
        val groups = listOf(
            HudGroupSpec("minimap", R.string.settings_hud_minimap),
            HudGroupSpec("timers", R.string.settings_hud_timers),
            HudGroupSpec("rings", R.string.settings_hud_rings),
            HudGroupSpec("collect", R.string.settings_hud_collect),
            HudGroupSpec("ranking", R.string.settings_hud_ranking),
            HudGroupSpec("indicators", R.string.settings_hud_indicators)
        )
        groups.forEachIndexed { index, group ->
            val section = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            section.addView(TextView(this).apply {
                text = getString(group.titleRes)
                setTextColor(android.graphics.Color.parseColor("#E0F2FE"))
                textSize = 13f
                typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL)
            })
            addHudSlider(section, prefs, group.key, "x", R.string.settings_hud_x, -160, 160, 0) { "$it px" }
            addHudSlider(section, prefs, group.key, "y", R.string.settings_hud_y, -120, 120, 0) { "$it px" }
            addHudSlider(section, prefs, group.key, "scale", R.string.settings_hud_size, 50, 150, 100) { "$it%" }
            addHudSlider(section, prefs, group.key, "opacity", R.string.settings_hud_opacity, 0, 100, 100) { "$it%" }
            container.addView(section)
            if (index != groups.lastIndex) {
                container.addView(View(this).apply {
                    setBackgroundColor(android.graphics.Color.parseColor("#334A6078"))
                }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
            }
        }
    }

    private fun addHudSlider(
        parent: LinearLayout,
        prefs: android.content.SharedPreferences,
        group: String,
        suffix: String,
        labelRes: Int,
        min: Int,
        max: Int,
        defaultValue: Int,
        formatValue: (Int) -> String
    ) {
        val key = "hud_${group}_${suffix}"
        val current = prefs.getInt(key, defaultValue).coerceIn(min, max)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(this).apply {
            text = getString(labelRes)
            setTextColor(android.graphics.Color.parseColor("#B8C8D8"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        val value = TextView(this).apply {
            text = formatValue(current)
            setTextColor(android.graphics.Color.parseColor("#FFE600"))
            textSize = 11f
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL)
            gravity = android.view.Gravity.END
            layoutParams = LinearLayout.LayoutParams(dp(72), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
        row.addView(value)
        parent.addView(row)
        val seek = SeekBar(this).apply {
            this.max = max - min
            progress = current - min
            progressTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FFE600"))
            thumbTintList = android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FFE600"))
            isFocusable = true
            isFocusableInTouchMode = true
            contentDescription = getString(labelRes)
            minimumHeight = dp(30)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(34))
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val selected = (min + progress).coerceIn(min, max)
                value.text = formatValue(selected)
                if (fromUser) prefs.edit().putInt(key, selected).apply()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        parent.addView(seek)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()

}
